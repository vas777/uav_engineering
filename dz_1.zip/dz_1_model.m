% Define the symbolic variables
mass_quadrotor = 1.07;
g = 9.81;
lever = 0.214; % meters

% The moment of inertia for the whole body
I = [ 0.0093, 0, 0;
      0, 0.0092, 0;
      0, 0, 0.0151
    ];

% thrust coefficient
b_thrust_coeff = 1.5108*10^(-5);

% inertia of the whole propeller is
Ip_inertia = 4.439*10^(-5);

% moment of inertia
Jl_mom_inertia = 4.927*10^(-6);
Jm_mom_inertia = 2.506*10^(-6);
%time constant 
taunp = 0.5;
% drag factor 
d_grag_factor = 4.406*10*(-7);
% ???
wm0 = 82*2*pi;



